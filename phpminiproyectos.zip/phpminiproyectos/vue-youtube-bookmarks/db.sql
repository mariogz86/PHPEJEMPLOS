CREATE TABLE `youtube_bookmarks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(65) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
