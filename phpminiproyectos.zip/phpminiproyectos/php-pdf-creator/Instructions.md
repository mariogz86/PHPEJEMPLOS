# Getting Started

Head to github to access the `mpdf` project.
Check it out [here](https://github.com/mpdf/mpdf).

Create your project folder and run composer to get the project

```bash
composer require mpdf/mpdf
```

If you don't have composer you can get for windows [here](https://getcomposer.org/)

Next you want to head to get your WYSIWYG editor.
Head to the project website which can be found [here](https://alex-d.github.io/Trumbowyg/)

You can download the files or use the CDN.

Thats it.

Run the project.
