<?php 

include "queue.php";

echo getLastItem();