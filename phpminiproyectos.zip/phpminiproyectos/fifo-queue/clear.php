<?php

include "queue.php";

emptyQueue();