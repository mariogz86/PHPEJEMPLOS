# PHP Has actuall Queue Functions

Check out the SPL Library

https://www.php.net/manual/en/book.spl.php