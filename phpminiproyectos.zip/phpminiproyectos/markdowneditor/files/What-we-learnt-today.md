# What we learnt today

* How to create a file using `fopen` and `fwrite` and `fclose`.
* How to list file in a directory
