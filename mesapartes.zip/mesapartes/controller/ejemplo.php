<?php 



echo 'http://'.$_SERVER['HTTP_HOST'].'/mesapartes/reporte/img/sello.png';