# Mesa-de-Partes
Sistema de Mesa de Partes Virtual realizado con HTML, CSS, JS, AJAX, MYSQL y PHP;  tiene como funcionalidad la recepción de trámites virtuales a traves de formularios y a la vez poder hacer la revisión y la derivación correspondiente a las distintas áreas de la organización. Modelo MVC
